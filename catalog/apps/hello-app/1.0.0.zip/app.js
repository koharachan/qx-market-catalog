import { onInit } from '/assets/js/app-bridge.js';

const btn = document.getElementById('btn');
let n = 0;
btn.addEventListener('click', () => {
  n += 1;
  btn.textContent = `点击：${n} 次`;
});

onInit((ctx) => {
  document.getElementById('host').textContent = `主机：${ctx.hostId || '-'}`;
});
