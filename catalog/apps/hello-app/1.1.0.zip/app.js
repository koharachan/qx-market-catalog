import { onInit } from '/assets/js/app-bridge.js';

const btn = document.getElementById('btn');
const goal = document.getElementById('goal');
let n = 0;
btn.addEventListener('click', () => {
  n += 1;
  btn.textContent = `点击：${n} 次`;
  if (n === 10) {
    goal.textContent = '惊喜达成：你点满了 10 次（v1.1.0）';
  }
});

onInit((ctx) => {
  document.getElementById('host').textContent = `主机：${ctx.hostId || '-'}`;
});
