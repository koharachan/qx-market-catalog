import { onInit, setTitle, openApp } from '/assets/js/app-bridge.js';

const $state = document.getElementById('state');
const $body = document.getElementById('body');

let hostId = null;

function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
}

function card(title, rows) {
  const c = el('section', 'si-card');
  c.append(el('div', 'si-card-title', title));
  for (const [k, v, mono] of rows) {
    if (v == null || v === '') continue;
    const row = el('div', 'si-row');
    row.append(el('span', 'si-k', k), el('span', `si-v${mono ? ' mono' : ''}`, String(v)));
    c.append(row);
  }
  return c;
}

function barCard(title, rows) {
  const c = el('section', 'si-card');
  c.append(el('div', 'si-card-title', title));
  for (const [label, value, total] of rows) {
    if (!total) continue;
    const wrap = el('div', 'si-bar-item');
    const pct = Math.max(0, Math.min(100, (value / total) * 100));
    wrap.append(el('div', 'si-row', ''));
    const row = wrap.firstChild;
    row.append(el('span', 'si-k', label), el('span', 'si-v', `${(pct).toFixed(1)}%`));
    const track = el('div', 'si-bar-track');
    const fill = el('div', 'si-bar-fill');
    fill.style.width = `${pct}%`;
    track.append(fill);
    wrap.append(track);
    c.append(wrap);
  }
  return c;
}

function gb(bytes) {
  if (!bytes) return '-';
  const v = bytes / 1024 ** 3;
  return `${v >= 100 ? v.toFixed(0) : v.toFixed(2)} GB`;
}

async function load() {
  if (!hostId) return;
  $state.className = 'si-badge';
  $state.textContent = '读取中…';
  $body.replaceChildren(
    (() => { const d = el('div', 'qx-empty'); d.append(el('span', 'qx-spinner'), el('span', '', '正在读取被控机配置…')); return d; })(),
  );
  try {
    const res = await fetch(`/api/hostinfo?host=${encodeURIComponent(hostId)}`);
    const c = await res.json();
    if (c.error) throw new Error(c.error);

    const cpu = [c.cpuModel, c.cpuVendor && c.cpuVendor !== c.cpuModel ? `(${c.cpuVendor})` : '']
      .filter(Boolean).join(' ');

    const nodes = [
      card('主机', [
        ['主机名', c.hostname],
        ['操作系统', c.os],
        ['内核', c.kernel],
        ['架构', c.arch],
        ['运行时长', c.uptime],
        ['网络地址', c.net],
      ]),
      card('处理器', [
        ['型号', cpu || '-'],
        ['物理核心', c.cores ? `${c.cores} 核` : '-'],
        ['逻辑线程', c.threads ? `${c.threads} 线程` : '-'],
        ['最高频率', c.cpuFreq || '-'],
      ]),
      card('内存', [
        ['总容量', c.memTotal ? gb(c.memTotal) : '-'],
        ['类型', c.memType || '未知'],
        ['频率', c.memSpeed || '未知'],
      ]),
      card('磁盘设备', (c.disks || []).map((d) => [
        d.name,
        `${gb(d.size)}${d.type && d.type !== '-' ? ' · ' + d.type : ''}${d.tran ? ' · ' + d.tran : ''}`,
        true,
      ])),
      card('文件系统', (c.storage || []).map((s) => [
        `${s.device || s.mount}${s.isSystem ? '（系统盘）' : ''}`,
        `${gb(s.usedBytes)} / ${gb(s.totalBytes)}`,
        true,
      ])),
    ];

    if (c.rootTotal) {
      nodes.splice(3, 0, barCard('根分区 (/)', [['已用空间', c.rootUsed || 0, c.rootTotal]]));
    }

    $body.replaceChildren(...nodes.filter((n) => n.childElementCount > 1));
    $state.textContent = '已读取';
  } catch (err) {
    $state.className = 'si-badge err';
    $state.textContent = '读取失败';
    const d = el('div', 'qx-empty');
    d.append(el('div', '', `无法读取被控机配置：${err.message}`));
    $body.replaceChildren(d);
  }
}

document.getElementById('refresh').addEventListener('click', load);
document.getElementById('open-files').addEventListener('click', () => openApp('files', { cwd: '/' }));

onInit((ctx) => {
  hostId = ctx.hostId;
  setTitle('系统信息');
  load();
});
