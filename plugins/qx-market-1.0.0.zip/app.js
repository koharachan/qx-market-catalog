/* QxSSH 插件市场（qx-market）主逻辑。
   纯前端：catalog.js 拉目录（多源 + 缓存降级）→ 浏览器 fetch 版本 zip（resolveZipUrl 拼绝对 URL）
   → hash.js verifyBlob 校验 sha256（硬失败；仅非安全上下文如局域网 http IP 时降级为明示警告）
   → hostapi.js installZip（FormData file，同 id 覆盖即换版）/ uninstallApp；
   已安装列表 listApps({userOnly:true})（systemApp!==true 才是用户应用）。
   bridge.js 对接宿主 app-bridge，加载失败自动降级 stub，不阻断商店主流程。 */
import { h, icon, fmtSize, fmtDate, spinner } from './lib/ui.js';
import { listApps, installZip, validateZip, uninstallApp, HostApiError } from './lib/hostapi.js';
import { fetchCatalog, getSources, setSources, resetSources, clearCache, resolveZipUrl, CatalogError } from './lib/catalog.js';
import { compare as semverCompare, isUpgrade } from './lib/semver.js';
import { verifyBlob } from './lib/hash.js';
import * as bridge from './lib/bridge.js';

/* ---------- 常量：市场自身（t26 自管理契约） ----------
   市场自身不是被上架的应用（不在 catalog 中），因此：
   ① 已安装视图如实显示这一行，但必须自我标注「本插件（插件市场）」；
   ② 禁止对自身发出 DELETE /api/apps/qx-market（UI 阻断 + doUninstall 硬防护）；
   ③ 无更新源：不显示「可更新」徽标、不提供版本下拉换版；
   ④ 自身更新只展示 URL 与文字说明，绝不由市场对自身发起 install/覆盖安装。 */
const SELF_ID = 'qx-market';
const SELF_VERSION_FALLBACK = '1.0.0';
const SELF_CATALOG_REPO = 'koharachan/qx-market-catalog';
const SELF_UNINSTALL_HINT = '插件市场不能在自身内卸载；如需移除，请在宿主应用管理中操作。';
const SELF_OVERWRITE_HINT = '该 zip 是插件市场自身（' + SELF_ID + '），不能在运行中覆盖安装；请在宿主应用管理中重新安装。';
const SELF_BLIND_HINT = '无法确认该 zip 的应用 id（本地无法解析，且宿主校验接口不可用）；为避免在运行中覆盖插件市场自身，已拒绝安装。请在宿主应用管理中安装该包。';

function isSelfApp(a) { return !!a && a.id === SELF_ID; }

/* ---------- zip 内 manifest.id 本地探测（t26 自覆盖防护本地兜底） ----------
   为什么需要：宿主 /api/apps/validate 不可用（接口异常、老宿主）时 validateZip 会抛错被
   catch 成 null，仅靠宿主探测就会放行并真的对自身发出 POST /api/apps/install——实测见
   /tmp/qxm-verify/t26b/logs/probe-selfoverwrite.log（validate 被中断后 install 照发，
   conf 内 qx-market/app.js 的 inode 由 54693 变 56389）。故这里在浏览器内直接读 zip 中央目录、
   解出 manifest.json，不依赖宿主、不引入任何依赖库。
   解析失败一律返回 null（不猜、不误判）；调用方策略：判不出 id 就拒绝本地上传安装。 */
const ZIP_EOCD_SIG = 0x06054b50, ZIP_CD_SIG = 0x02014b50, ZIP_LH_SIG = 0x04034b50;

function zipU16(b, o) { return b[o] | (b[o + 1] << 8); }
function zipU32(b, o) { return (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0; }
function zipUtf8(b, o, n) { return new TextDecoder('utf-8', { fatal: false }).decode(b.subarray(o, o + n)); }

/** 本地读出 zip 内 manifest.json 的 manifest.id；任何解析异常或读不出都返回 null。 */
async function peekZipAppId(file) {
  const b = new Uint8Array(await file.arrayBuffer());
  /* 1) 尾部找 EOCD（固定 22 字节 + zip comment 最长 65535） */
  let eocd = -1;
  const min = Math.max(0, b.length - 65557);
  for (let i = b.length - 22; i >= min; i--) { if (zipU32(b, i) === ZIP_EOCD_SIG) { eocd = i; break; } }
  if (eocd < 0) return null;
  let off = zipU32(b, eocd + 16);
  const total = zipU16(b, eocd + 10);
  /* 2) 遍历中央目录，取路径最短的 manifest.json（根目录优先） */
  let best = null;
  for (let n = 0; n < total; n++) {
    if (off + 46 > b.length || zipU32(b, off) !== ZIP_CD_SIG) return null;
    const method = zipU16(b, off + 10);
    const compSize = zipU32(b, off + 20);
    const nameLen = zipU16(b, off + 28), extraLen = zipU16(b, off + 30), cmtLen = zipU16(b, off + 32);
    const localOff = zipU32(b, off + 42);
    const name = zipUtf8(b, off + 46, nameLen);
    if (/(^|\/)manifest\.json$/i.test(name) && (!best || name.length < best.name.length)) {
      best = { name, method, compSize, localOff };
    }
    off += 46 + nameLen + extraLen + cmtLen;
  }
  if (!best) return null;
  /* 3) 按本地头（其 name/extra 长度可与中央目录不同）定位数据区 */
  const lh = best.localOff;
  if (lh + 30 > b.length || zipU32(b, lh) !== ZIP_LH_SIG) return null;
  const dataStart = lh + 30 + zipU16(b, lh + 26) + zipU16(b, lh + 28);
  const data = b.subarray(dataStart, dataStart + best.compSize);
  if (data.length !== best.compSize) return null;
  let text;
  if (best.method === 0) {
    text = zipUtf8(data, 0, data.length);
  } else if (best.method === 8 && typeof DecompressionStream === 'function') {
    text = await new Response(new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).text();
  } else {
    return null; /* 加密 / zip64 / 非常见压缩法：本地判不出，交宿主 validate 判定 */
  }
  const manifest = JSON.parse(text);
  return (manifest && typeof manifest.id === 'string') ? manifest.id : null;
}

/** 自身版本号：优先取宿主 GET /api/apps 的真实 manifest.version。 */
function selfVersion() {
  const inst = state.installed.get(SELF_ID);
  return (inst && inst.version) || SELF_VERSION_FALLBACK;
}

/** 自身引导/更新 URL（仅展示；市场绝不对自身发起安装）。 */
function selfZipUrls() {
  const file = 'plugins/' + SELF_ID + '-' + selfVersion() + '.zip';
  return [
    'https://cdn.jsdelivr.net/gh/' + SELF_CATALOG_REPO + '@main/' + file,
    'https://raw.githubusercontent.com/' + SELF_CATALOG_REPO + '/main/' + file,
  ];
}

/* ---------- 常量与状态 ---------- */
const state = {
  view: 'market',            // installed | market | settings
  tab: 'all',                // installed 页筛选：all | updates
  keyword: '',
  category: 'all',
  catalog: null,             // { schema, name, updatedAt, apps[] }
  catalogUrl: '',            // 实际命中的目录 URL（zip 相对路径的解析基准）
  catalogStale: false,       // 是否缓存降级
  installed: new Map(),      // id → manifest
  marketStatus: 'loading',   // loading | error | success
  marketError: '',
  marketAttempts: [],        // CatalogError.attempts / 降级提示
  installedStatus: 'loading',
  installedError: '',
  busy: new Map(),           // key（id 或 id@version）→ {phase, pct, note, isError}
  uploadBusy: null,          // {note}
  settingsMsg: null,         // {text, isError}
  dialog: null,              // {title, warn, lines, okText, cancelText, resolve}
  toast: null,               // {text, kind}
  bridgeStub: true,
};

let toastTimer = 0;
function toast(text, kind = 'info') {
  state.toast = { text, kind };
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { state.toast = null; render(); }, 3200);
  bridge.toast(text, kind).catch(() => {});
  render();
}

/* ---------- 纯函数：版本与匹配 ---------- */
function sortedVersions(app) {
  return [...(app.versions || [])].sort((x, y) => {
    try { return semverCompare(y.version, x.version); } catch { return 0; }
  });
}
function latestEntry(app) {
  const list = sortedVersions(app);
  return list.find((v) => v.version === app.latest) || list[0] || null;
}
function hasUpdate(app) {
  const inst = state.installed.get(app.id);
  const latest = latestEntry(app);
  return !!(inst && latest && isUpgrade(inst.version || '0.0.0', latest.version));
}
function matchKeyword(app, kw) {
  if (!kw) return true;
  const hay = [app.id, app.name, app.description, app.author, app.category, ...(app.keywords || [])]
    .filter(Boolean).join(' ').toLowerCase();
  return kw.toLowerCase().split(/\s+/).every((w) => hay.includes(w));
}
function catalogCategories(apps) {
  const set = new Set();
  for (const a of apps) if (a.category) set.add(a.category);
  return [...set].sort((x, y) => x.localeCompare(y, 'zh'));
}

/* ---------- 数据加载 ---------- */
async function loadCatalog({ force = false } = {}) {
  state.marketStatus = 'loading';
  state.marketError = '';
  state.marketAttempts = [];
  render();
  try {
    const r = await fetchCatalog({ force });
    state.catalog = r.catalog;
    state.catalogUrl = r.url;
    state.catalogStale = !!r.stale;
    state.marketStatus = 'success';
    if (r.stale && r.warning) toast(r.warning, 'warn');
  } catch (e) {
    state.catalog = null;
    state.marketStatus = 'error';
    state.marketError = e instanceof CatalogError ? e.message : (e.message || String(e));
    state.marketAttempts = e instanceof CatalogError ? (e.attempts || []) : [];
  }
  render();
}

async function loadInstalled() {
  state.installedStatus = 'loading';
  state.installedError = '';
  render();
  try {
    const apps = await listApps({ userOnly: true });
    state.installed = new Map(apps.filter((a) => a && a.id).map((a) => [a.id, a]));
    state.installedStatus = 'success';
  } catch (e) {
    state.installedStatus = 'error';
    state.installedError = e.message || String(e);
  }
  render();
}

/* ---------- 安装流水线 ---------- */
function setBusy(key, val) {
  if (val) state.busy.set(key, val);
  else state.busy.delete(key);
  render();
}

/** 下载 zip（进度回报）→ File。sha256 校验由调用方做。 */
async function fetchZip(zipUrl, fallbackSize, onProgress) {
  onProgress({ phase: 'download', pct: 0 });
  const r = await fetch(zipUrl);
  if (!r.ok) throw new Error('下载失败：HTTP ' + r.status);
  const total = Number(r.headers.get('Content-Length')) || fallbackSize || 0;
  let buf;
  if (r.body && r.body.getReader) {
    const reader = r.body.getReader();
    const chunks = [];
    let got = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
      got += value.length;
      onProgress({ phase: 'download', pct: total ? Math.min(99, Math.round((got / total) * 100)) : -1 });
    }
    buf = new Uint8Array(got);
    let off = 0;
    for (const c of chunks) { buf.set(c, off); off += c.length; }
  } else {
    buf = new Uint8Array(await r.arrayBuffer());
  }
  const name = zipUrl.split('/').pop().split('?')[0] || 'app.zip';
  return new File([buf], name, { type: 'application/zip' });
}

/** hash.js 校验 zip；crypto.subtle 不可用（非安全上下文）时明示风险由用户决定。 */
async function verifyZipIntegrity(file, expectHex) {
  const expect = String(expectHex || '').trim().toLowerCase();
  if (!expect) return;
  if (typeof crypto === 'undefined' || !crypto.subtle) {
    const ok = await confirmDialog({
      title: '无法校验安装包完整性',
      warn: true,
      lines: [
        '当前页面运行于非安全上下文（通常是以局域网 IP 通过 http 访问宿主），浏览器未提供 crypto.subtle，无法校验 sha256。',
        '继续安装意味着接受未校验完整性的包，存在被篡改的风险。建议改用 https 或 127.0.0.1/localhost 访问。',
      ],
      okText: '我已知晓风险，继续安装',
    });
    if (!ok) throw new Error('已取消：完整性未校验');
    return;
  }
  const { ok, actual } = await verifyBlob(file, expect);
  if (!ok) throw new Error('校验和不匹配：期望 ' + expect.slice(0, 16) + '… 实际 ' + String(actual).slice(0, 16) + '…（安装已中止）');
}

/** 安装 catalog 中某应用某版本（同 id 覆盖安装 = 自由换版/升降级）。 */
async function installVersion(app, version) {
  const key = app.id + '@' + version;
  if (state.busy.has(key) || state.busy.has(app.id)) return;
  const v = (app.versions || []).find((x) => x.version === version);
  if (!v) { toast('目录中不存在版本 ' + version, 'error'); return; }
  const inst = state.installed.get(app.id);
  const isSwitch = !!inst;
  setBusy(key, { phase: 'download', pct: 0, note: '' });
  try {
    const zipUrl = resolveZipUrl(state.catalogUrl, v.zip);
    const file = await fetchZip(zipUrl, v.size, (p) => setBusy(key, { ...p, note: '' }));
    setBusy(key, { phase: 'verify', pct: 100, note: '' });
    await verifyZipIntegrity(file, v.sha256);
    setBusy(key, { phase: 'install', pct: 100, note: '' });
    await installZip(file, file.name);
    setBusy(key, null);
    toast((app.name || app.id) + ' ' + version + (isSwitch ? ' 已切换（覆盖安装）' : ' 安装完成'), 'success');
    bridge.notifyAppsChanged().catch(() => {});
    await loadInstalled();
  } catch (e) {
    const msg = e.message || String(e);
    setBusy(key, { phase: 'error', pct: 0, note: msg, isError: true });
    setTimeout(() => { if (state.busy.get(key)?.isError) setBusy(key, null); }, 6000);
    toast(msg, 'error');
  }
}

async function doUninstall(appLike) {
  const id = appLike.id;
  /* 硬防护（t26）：无论从哪个入口到达，都绝不对市场自身发出 DELETE /api/apps/qx-market。 */
  if (id === SELF_ID) { blockSelfUninstall(); return; }
  if (state.busy.has(id)) return;
  setBusy(id, { phase: 'uninstall', pct: -1, note: '' });
  try {
    await uninstallApp(id);
    setBusy(id, null);
    toast((appLike.name || id) + ' 已卸载', 'success');
    bridge.notifyAppsChanged().catch(() => {});
    await loadInstalled();
  } catch (e) {
    setBusy(id, null);
    toast(e.message || String(e), 'error');
  }
}

/** 本地 zip 上传安装（降级入口：任意旧版本包均可，同 id 覆盖）。
    例外（t26）：包内 manifest.id 为市场自身时拒绝——不允许运行中自覆盖安装。
    三重判定，任一命中即拒绝：
      ① 本地读 zip 内 manifest.id（peekZipAppId，不依赖宿主；实测宿主 validate 不可用时
         原实现会放行并真的对自身发起覆盖安装，故本地通道是必需的硬拦截）；
      ② 宿主 POST /api/apps/validate 只读探测（能读懂本地读不了的 zip 形态）；
      ③ ①②都判不出 id 时拒绝安装（宁可拒绝，也不放行可能覆盖市场自身的不确定包）。 */
async function uploadLocalZip(file) {
  if (!file || state.uploadBusy) return;
  state.uploadBusy = { note: '正在校验并安装 ' + file.name + '…' };
  render();
  try {
    const localId = await peekZipAppId(file).catch(() => null);
    if (localId === SELF_ID) throw new Error(SELF_OVERWRITE_HINT);
    const probe = await validateZip(file, file.name).catch(() => null);
    if (probe && probe.app && probe.app.id === SELF_ID) throw new Error(SELF_OVERWRITE_HINT);
    if (!localId && !probe) throw new Error(SELF_BLIND_HINT);
    await installZip(file, file.name);
    state.uploadBusy = null;
    toast(file.name + ' 安装完成（若为已装应用同 id，则已覆盖换版）', 'success');
    bridge.notifyAppsChanged().catch(() => {});
    await loadInstalled();
  } catch (e) {
    state.uploadBusy = null;
    toast(e.message || String(e), 'error');
  }
  render();
}

/* ---------- 确认对话框 ---------- */
function confirmDialog({ title, warn = false, lines = [], fields = null, okText = '确定', cancelText = '取消' }) {
  return new Promise((resolve) => {
    state.dialog = { title, warn, lines, fields, okText, cancelText, resolve };
    render();
  });
}
/** 单按钮告知对话框（cancelText=null 时不渲染取消按钮）。 */
function noticeDialog({ title, lines = [], okText = '知道了' }) {
  return new Promise((resolve) => {
    state.dialog = { title, warn: false, lines, fields: null, okText, cancelText: null, resolve };
    render();
  });
}
/** 市场自卸载阻断提示：只提示，不发出任何请求。 */
function blockSelfUninstall() {
  noticeDialog({
    title: '本插件不能在市场内卸载',
    lines: [
      SELF_UNINSTALL_HINT,
      '当前界面正由插件市场自身提供，在自身运行中删除会立即中断本界面。',
      '自身更新同样不在本界面进行：请按「设置 → 关于本插件」列出的 URL，在宿主应用管理中重新安装。',
    ],
    okText: '知道了',
  });
}
function closeDialog(result) {
  const d = state.dialog;
  state.dialog = null;
  render();
  if (d) d.resolve(result);
}

/* ---------- 视图：骨架 ---------- */
const root = document.getElementById('app');

const TABS = [
  { id: 'installed', label: '已安装', icon: 'grid' },
  { id: 'market', label: '应用市场', icon: 'store' },
  { id: 'settings', label: '设置', icon: 'settings' },
];

function updateCount() {
  if (!state.catalog) return 0;
  return state.catalog.apps.filter(hasUpdate).length;
}

function render() {
  const updates = updateCount();
  const bar = h('div', { class: 'qxm-topbar' },
    h('div', { class: 'qxm-logo' }, icon('store'), '插件市场'),
    h('div', { class: 'qxm-tabs', role: 'tablist' },
      TABS.map((t) => h('button', {
        class: 'qxm-tab', role: 'tab', type: 'button',
        'aria-selected': state.view === t.id ? 'true' : 'false',
        onclick: () => { state.view = t.id; render(); },
      },
        icon(t.icon), t.label,
        t.id === 'installed' && updates > 0
          ? h('span', { class: 'qxm-badge qxm-badge-update' }, String(updates) + ' 更新')
          : null)),
    ),
    state.view !== 'settings' ? h('div', { class: 'qxm-search' },
      icon('search'),
      h('input', {
        type: 'search', placeholder: '搜索名称、标识、关键词…', value: state.keyword,
        'aria-label': '搜索应用',
        oninput: (e) => { state.keyword = e.target.value; renderBody(); },
      }),
    ) : null,
    h('div', { class: 'qx-app-bar-end' }),
    h('button', {
      class: 'btn btn-ghost btn-sm', type: 'button', title: '刷新目录与已安装列表',
      onclick: () => { loadCatalog({ force: true }); loadInstalled(); },
    }, icon('refresh'), '刷新'),
  );

  const body = h('div', { class: 'qxm-body', id: 'qxm-body' });
  root.replaceChildren(bar, body, renderToast(), renderDialog() || '');
  renderBody();
}

function renderBody() {
  const body = document.getElementById('qxm-body');
  if (!body) return;
  body.replaceChildren(
    state.view === 'settings' ? viewSettings()
      : state.view === 'installed' ? viewInstalled()
        : viewMarket());
}

/* ---------- 视图：状态块 ---------- */
function stateBlock(kind, title, desc, actions = []) {
  return h('div', { class: 'qxm-state' + (kind === 'error' ? ' is-error' : '') },
    kind === 'loading' ? spinner() : icon(kind === 'error' ? 'alert' : 'info'),
    h('div', { class: 'qxm-state-title' }, title),
    desc ? h('div', { class: 'qxm-state-desc' }, desc) : null,
    actions.length ? h('div', { class: 'qxm-field', style: 'justify-content:center' }, actions) : null);
}

/* ---------- 视图：应用市场 ---------- */
function viewMarket() {
  if (state.marketStatus === 'loading') return stateBlock('loading', '正在拉取应用目录…', getSources()[0] || '');
  if (state.marketStatus === 'error') {
    const desc = [state.marketError + '。可在「设置」中更换目录源地址。'];
    if (state.marketAttempts.length) {
      desc.push(...state.marketAttempts.slice(0, 4).map((a) => a.url + ' → ' + a.error));
    }
    return stateBlock('error', '目录源拉取失败', desc.join('\n'),
      [h('button', { class: 'btn btn-primary btn-sm', type: 'button', onclick: () => loadCatalog({ force: true }) }, icon('refresh'), '重试'),
       h('button', { class: 'btn btn-ghost btn-sm', type: 'button', onclick: () => { state.view = 'settings'; render(); } }, icon('settings'), '前往设置')]);
  }
  /* 浏览列表只来自 catalog（不混入已安装列表）；防御性地再排除市场自身：
     它是客户端而非被上架的应用，若目录误收录也不应在这里出现安装入口。 */
  const apps = state.catalog.apps.filter((a) => a.id !== SELF_ID);
  const cats = catalogCategories(apps);
  const filtered = apps.filter((a) =>
    (state.category === 'all' || a.category === state.category) && matchKeyword(a, state.keyword));

  const frag = [];
  frag.push(h('div', { class: 'qxm-chips', role: 'group', 'aria-label': '分类筛选' },
    h('button', {
      class: 'qxm-chip', type: 'button', 'aria-pressed': state.category === 'all' ? 'true' : 'false',
      onclick: () => { state.category = 'all'; renderBody(); },
    }, '全部（' + apps.length + '）'),
    cats.map((c) => h('button', {
      class: 'qxm-chip', type: 'button', 'aria-pressed': state.category === c ? 'true' : 'false',
      onclick: () => { state.category = c; renderBody(); },
    }, c + '（' + apps.filter((a) => a.category === c).length + '）'))));

  if (state.catalogStale) {
    frag.push(h('div', { class: 'qxm-card-note', style: 'padding:8px 2px 0' }, icon('clock'), '所有目录源均不可达，当前展示本地缓存目录，可能与源站不同步。'));
  }
  if (!filtered.length) {
    frag.push(stateBlock('empty', state.keyword || state.category !== 'all' ? '没有匹配的应用' : '目录为空',
      state.keyword ? '换个关键词或分类试试。' : '目录源中暂无应用，可更换目录源或稍后再试。'));
  } else {
    frag.push(h('div', { class: 'qxm-grid' }, filtered.map((a) => marketCard(a))));
  }
  return h('div', null, frag);
}

function versionSelect(app, current, disabled) {
  return h('select', {
    class: 'qxm-ver', 'aria-label': '选择版本', disabled: disabled || undefined,
    onchange: (e) => {
      const v = e.target.value;
      if (!v || v === current) return;
      installVersion(app, v);
    },
  },
    sortedVersions(app).map((v) => h('option', {
      value: v.version, selected: v.version === current ? 'selected' : undefined,
      title: [v.date ? fmtDate(v.date) : null, v.changelog || null].filter(Boolean).join(' — '),
    },
      v.version + (v.version === app.latest ? ' · 最新' : ''))));
}

function busyRow(b) {
  return h('div', { style: 'flex:1;display:flex;flex-direction:column;gap:6px;min-width:140px' },
    b.pct != null && b.phase === 'download'
      ? h('div', { class: 'qxm-progress' }, h('div', { style: 'width:' + (b.pct < 0 ? '100%' : b.pct + '%') + ';opacity:' + (b.pct < 0 ? '.4' : '1') }))
      : null,
    h('div', { class: 'qxm-card-note' + (b.isError ? ' is-error' : '') }, b.isError ? icon('alert') : spinner(), phaseText(b)));
}

function marketCard(app) {
  const inst = state.installed.get(app.id);
  const latest = latestEntry(app);
  const upd = hasUpdate(app);
  const busy = [...state.busy.entries()].find(([k]) => k === app.id || k.startsWith(app.id + '@'));
  const current = inst ? inst.version : (latest ? latest.version : '');

  const foot = [];
  if (busy) {
    foot.push(busyRow(busy[1]));
  } else {
    if (inst) {
      foot.push(versionSelect(app, current, false));
      foot.push(h('button', {
        class: 'btn btn-primary btn-sm', type: 'button',
        onclick: () => latest && installVersion(app, latest.version),
      }, icon('download'), upd ? '更新' : '重装'));
      foot.push(h('button', {
        class: 'btn btn-ghost btn-sm', type: 'button', title: '卸载',
        onclick: () => askUninstall(app),
      }, icon('trash')));
    } else {
      foot.push(versionSelect(app, current, !latest));
      foot.push(h('button', {
        class: 'btn btn-primary btn-sm', type: 'button', disabled: !latest,
        onclick: () => latest && installVersion(app, latest.version),
      }, icon('download'), '安装'));
    }
  }

  return h('article', { class: 'qxm-card' },
    h('div', { class: 'qxm-card-head' },
      h('div', { class: 'qxm-icon' }, icon(app.icon)),
      h('div', { class: 'qxm-card-title' },
        h('div', { class: 'qxm-card-name' }, app.name || app.id,
          inst ? h('span', { class: 'qxm-badge qxm-badge-installed' }, icon('check'), '已装 ' + (inst.version || '?')) : null,
          upd ? h('span', { class: 'qxm-badge qxm-badge-update' }, '可更新') : null),
        h('div', { class: 'qxm-card-meta' },
          h('span', { class: 'mono' }, app.id),
          app.author ? h('span', null, app.author) : null,
          app.category ? h('span', { class: 'qxm-badge' }, app.category) : null))),
    h('p', { class: 'qxm-card-desc' }, app.description || '该应用未提供简介。'),
    h('div', { class: 'qxm-card-foot' }, foot),
    latest && latest.changelog ? h('div', { class: 'qxm-changelog' },
      '最新 ' + latest.version + (latest.date ? '（' + fmtDate(latest.date) + (latest.size ? ' · ' + fmtSize(latest.size) : '') + '）' : '') + '：' + latest.changelog) : null);
}

function phaseText(b) {
  if (b.isError) return b.note;
  if (b.phase === 'download') return b.pct < 0 ? '正在下载…' : '正在下载 ' + b.pct + '%';
  if (b.phase === 'verify') return '校验完整性…';
  if (b.phase === 'install') return '安装中…';
  if (b.phase === 'uninstall') return '卸载中…';
  return '处理中…';
}

/* ---------- 视图：已安装 ---------- */
function viewInstalled() {
  if (state.installedStatus === 'loading') return stateBlock('loading', '正在读取已安装应用…', 'GET /api/apps');
  if (state.installedStatus === 'error') {
    return stateBlock('error', '已安装列表读取失败', state.installedError,
      [h('button', { class: 'btn btn-primary btn-sm', type: 'button', onclick: loadInstalled }, icon('refresh'), '重试')]);
  }
  const list = [...state.installed.values()]
    .filter((a) => matchKeyword(a, state.keyword))
    .sort((x, y) => String(x.name || x.id).localeCompare(String(y.name || y.id), 'zh'));

  const withInfo = list.map((a) => {
    /* 市场自身：强制按「无目录条目」处理——无更新源、无换版、不显示可更新徽标。 */
    const self = a.id === SELF_ID;
    const cat = !self && state.catalog ? state.catalog.apps.find((c) => c.id === a.id) : null;
    return { inst: a, cat, upd: !!(cat && hasUpdate(cat)), self };
  });
  const updates = withInfo.filter((x) => x.upd);
  const shown = state.tab === 'updates' ? updates : withInfo;

  const frag = [];
  frag.push(h('div', { class: 'qxm-chips', role: 'group', 'aria-label': '已安装筛选' },
    h('button', { class: 'qxm-chip', type: 'button', 'aria-pressed': state.tab === 'all' ? 'true' : 'false', onclick: () => { state.tab = 'all'; renderBody(); } }, '全部（' + withInfo.length + '）'),
    h('button', { class: 'qxm-chip', type: 'button', 'aria-pressed': state.tab === 'updates' ? 'true' : 'false', onclick: () => { state.tab = 'updates'; renderBody(); } }, '可更新（' + updates.length + '）'),
    updates.length ? h('button', {
      class: 'btn btn-primary btn-sm', type: 'button', style: 'margin-left:auto',
      onclick: () => updates.forEach((x) => { const latest = latestEntry(x.cat); if (latest) installVersion(x.cat, latest.version); }),
    }, icon('download'), '全部更新') : null));

  if (!shown.length) {
    frag.push(stateBlock('empty',
      state.tab === 'updates' ? '没有可更新的应用' : (state.keyword ? '没有匹配的已安装应用' : '尚未安装任何应用'),
      state.tab === 'updates' ? '全部已安装应用均为最新版本。' : (state.keyword ? '换个关键词试试。' : '前往「应用市场」浏览目录并安装。'),
      state.tab === 'all' && !state.keyword ? [h('button', { class: 'btn btn-primary btn-sm', type: 'button', onclick: () => { state.view = 'market'; render(); } }, icon('store'), '浏览应用市场')] : []));
  } else {
    frag.push(h('div', { class: 'qxm-grid' }, shown.map(installedCard)));
  }

  /* 本地 zip 安装（降级入口） */
  const fileInput = h('input', {
    type: 'file', accept: '.zip,application/zip', style: 'display:none',
    onchange: (e) => { const f = e.target.files[0]; e.target.value = ''; uploadLocalZip(f); },
  });
  frag.push(h('div', { class: 'qxm-panel', style: 'margin-top:14px' },
    h('div', { class: 'qxm-panel-title' }, icon('upload'), '本地包安装'),
    h('div', { class: 'qxm-panel-desc' }, '上传本地 zip 应用包安装；包内 manifest 的 id 与已装应用相同时将覆盖安装，可用于安装目录之外的旧版本（降级）。插件市场自身（qx-market）的包会被拒绝——不允许在运行中覆盖本插件；无法确认包内 id 时同样拒绝。'),
    state.uploadBusy
      ? h('div', { class: 'qxm-card-note' }, spinner(), state.uploadBusy.note)
      : h('div', null,
        h('button', { class: 'btn btn-ghost btn-sm', type: 'button', onclick: () => fileInput.click() }, icon('upload'), '选择 zip 文件'),
        fileInput)));

  return h('div', null, frag);
}

function installedCard({ inst, cat, upd, self }) {
  const busy = state.busy.get(inst.id) || [...state.busy.entries()].find(([k]) => k.startsWith(inst.id + '@'));
  const latest = cat ? latestEntry(cat) : null;

  const foot = [];
  if (busy) {
    const b = busy[1] || busy;
    foot.push(busyRow(b));
  } else {
    if (cat) foot.push(versionSelect(cat, inst.version, false));
    if (cat && upd && latest) {
      foot.push(h('button', { class: 'btn btn-primary btn-sm', type: 'button', onclick: () => installVersion(cat, latest.version) }, icon('download'), '更新到 ' + latest.version));
    } else if (cat && latest) {
      foot.push(h('button', { class: 'btn btn-ghost btn-sm', type: 'button', onclick: () => installVersion(cat, latest.version) }, icon('refresh'), '重装'));
    }
    if (self) {
      /* 自卸载入口：渲染出来但点击即阻断（doUninstall 内另有硬防护），绝不发 DELETE。
         注意不能加 aria-disabled/disabled——它必须可点击才能给出阻断说明。 */
      foot.push(h('button', {
        class: 'btn btn-ghost btn-sm qxm-self-block', type: 'button',
        'data-self-blocked': 'uninstall', title: SELF_UNINSTALL_HINT,
        onclick: blockSelfUninstall,
      }, icon('trash'), '卸载'));
    } else {
      foot.push(h('button', { class: 'btn btn-ghost btn-sm', type: 'button', title: '卸载', onclick: () => askUninstall(inst) }, icon('trash')));
    }
  }

  return h('article', { class: 'qxm-card' + (self ? ' is-self' : ''), dataset: self ? { appId: inst.id } : null },
    h('div', { class: 'qxm-card-head' },
      h('div', { class: 'qxm-icon' }, icon(inst.icon || (cat && cat.icon))),
      h('div', { class: 'qxm-card-title' },
        h('div', { class: 'qxm-card-name' }, inst.name || inst.id,
          self ? h('span', { class: 'qxm-badge qxm-badge-self' }, icon('store'), '本插件（插件市场）') : null,
          h('span', { class: 'qxm-badge qxm-badge-installed mono' }, 'v' + (inst.version || '?')),
          upd ? h('span', { class: 'qxm-badge qxm-badge-update' }, '可更新 → ' + latest.version) : null),
        h('div', { class: 'qxm-card-meta' },
          h('span', { class: 'mono' }, inst.id),
          inst.author ? h('span', null, inst.author) : null,
          self ? h('span', { class: 'qxm-badge' }, '宿主管理') : (cat ? null : h('span', { class: 'qxm-badge' }, '目录外'))))),
    h('p', { class: 'qxm-card-desc' }, inst.description || (cat && cat.description) || '该应用未提供简介。'),
    h('div', { class: 'qxm-card-foot' }, foot),
    self
      ? h('div', { class: 'qxm-card-note' }, icon('info'), '本插件（插件市场）不能在自身内卸载；如需移除，请在宿主应用管理中操作。自身更新方式：按「设置 → 关于本插件」的 URL 在宿主应用管理中重新安装。')
      : (cat ? null : h('div', { class: 'qxm-card-note' }, icon('info'), '不在当前目录源中，版本切换不可用；可上传本地 zip 覆盖换版。')));
}

function askUninstall(app) {
  /* 硬防护（t26）：市场自身永不进入卸载确认流程。 */
  if (isSelfApp(app)) { blockSelfUninstall(); return; }
  confirmDialog({
    title: '卸载 ' + (app.name || app.id),
    warn: true,
    lines: ['将从本机删除该应用（' + app.id + '）的文件。', '此操作不可撤销；目录内的应用可随时重新安装。'],
    okText: '卸载',
  }).then((ok) => { if (ok) doUninstall(app); });
}

/* ---------- 视图：设置 ---------- */
function viewSettings() {
  const msg = state.settingsMsg;
  const sources = getSources();
  const panels = [];

  /* 目录源（catalog.js 多源契约：列表存 localStorage，依次尝试） */
  const input = h('input', { type: 'url', value: sources[0] || '', 'aria-label': '目录源地址', spellcheck: 'false' });
  panels.push(h('div', { class: 'qxm-panel' },
    h('div', { class: 'qxm-panel-title' }, icon('link'), '目录源'),
    h('div', { class: 'qxm-panel-desc' },
      '应用目录 catalog.json 的完整 URL（GitHub raw / jsDelivr 等均可，须允许跨域访问）。各版本 zip 按相对该 URL 的路径解析；配置多个源时依次尝试。'),
    h('div', { class: 'qxm-field' },
      input,
      h('button', {
        class: 'btn btn-primary btn-sm', type: 'button',
        onclick: () => {
          const url = input.value.trim();
          try {
            setSources([url]);
          } catch (e) {
            state.settingsMsg = { text: e.message || String(e), isError: true };
            renderBody();
            return;
          }
          state.settingsMsg = { text: '目录源已保存，正在刷新目录…', isError: false };
          renderBody();
          loadCatalog({ force: true });
        },
      }, icon('check'), '保存并刷新'),
      h('button', {
        class: 'btn btn-ghost btn-sm', type: 'button',
        onclick: () => { resetSources(); state.settingsMsg = { text: '已恢复默认目录源，正在刷新…', isError: false }; renderBody(); loadCatalog({ force: true }); },
      }, '恢复默认')),
    h('div', { class: 'qxm-kv' },
      h('dt', null, '当前源'), h('dd', null, sources.join(' ; ')),
      h('dt', null, '命中源'), h('dd', null, state.catalogUrl || '-'),
      h('dt', null, '目录名称'), h('dd', null, (state.catalog && state.catalog.name) || '-'),
      h('dt', null, '更新时间'), h('dd', null, (state.catalog && state.catalog.updatedAt) || '-'),
      h('dt', null, '应用数量'), h('dd', null, state.catalog ? String(state.catalog.apps.length) : '-'),
      h('dt', null, '数据来源'), h('dd', null, state.catalog ? (state.catalogStale ? '本地缓存（源不可达）' : '实时拉取') : '-'))));

  /* 缓存 */
  panels.push(h('div', { class: 'qxm-panel' },
    h('div', { class: 'qxm-panel-title' }, icon('clock'), '目录缓存'),
    h('div', { class: 'qxm-panel-desc' }, '目录拉取成功后写入 localStorage（10 分钟内视为新鲜）；所有源不可达时回退到缓存。'),
    h('div', { class: 'qxm-field' },
      h('button', {
        class: 'btn btn-ghost btn-sm', type: 'button',
        onclick: () => { clearCache(); state.settingsMsg = { text: '目录缓存已清除，下次刷新将重新拉取。', isError: false }; renderBody(); },
      }, icon('trash'), '清除缓存'))));

  /* 关于本插件（t26）：只展示版本与引导/更新 URL，不提供一键自更新；
     市场绝不对自身发起 installFromUrl/installZip 覆盖安装。 */
  const selfUrls = selfZipUrls();
  const selfInst = state.installed.get(SELF_ID);
  panels.push(h('div', { class: 'qxm-panel', dataset: { panel: 'about-self' } },
    h('div', { class: 'qxm-panel-title' }, icon('info'), '关于本插件'),
    h('div', { class: 'qxm-kv' },
      h('dt', null, '插件标识'), h('dd', null, SELF_ID),
      h('dt', null, '名称'), h('dd', null, (selfInst && selfInst.name) || '插件市场'),
      h('dt', null, '当前版本'), h('dd', null, selfVersion()),
      h('dt', null, '引导 / 更新 URL ①'), h('dd', { class: 'qxm-url' }, selfUrls[0]),
      h('dt', null, '引导 / 更新 URL ②'), h('dd', { class: 'qxm-url' }, selfUrls[1]),
      h('dt', null, '完整性校验'), h('dd', null, (typeof crypto !== 'undefined' && crypto.subtle) ? 'sha256（crypto.subtle 可用）' : '不可用：非安全上下文，安装时将提示风险'),
      h('dt', null, '宿主桥接'), h('dd', null, state.bridgeStub ? '未检测到（独立调试模式）' : '已连接（/assets/js/app-bridge.js）')),
    h('div', { class: 'qxm-panel-desc' },
      '市场自身的更新方式是从上述 URL 重新安装：在宿主应用管理中下载该 zip 安装，或使用宿主的 URL 安装入口。',
      h('div', null, '本界面只展示地址与说明，不会对插件市场自身发起在线安装或覆盖安装——运行中覆盖会替换正在执行的页面文件，行为不确定。'),
      h('div', null, '卸载同理：插件市场不能在自身内卸载，请在宿主应用管理中操作。'))));

  return h('div', { class: 'qxm-settings' },
    msg ? h('div', { class: 'qxm-msg ' + (msg.isError ? 'is-error' : 'is-ok') }, icon(msg.isError ? 'alert' : 'check'), msg.text) : null,
    panels);
}

/* ---------- 视图：toast 与对话框 ---------- */
function renderToast() {
  if (!state.toast) return h('span', { style: 'display:none' });
  return h('div', {
    class: 'qxm-dialog', role: 'status',
    style: 'position:fixed;left:50%;bottom:18px;transform:translateX(-50%);width:auto;max-width:90vw;padding:8px 14px;z-index:60;flex-direction:row;align-items:center;gap:8px;font-size:.8rem',
  }, icon(state.toast.kind === 'error' ? 'alert' : 'check'), state.toast.text);
}

function renderDialog() {
  const d = state.dialog;
  if (!d) return null;
  return h('div', {
    class: 'qxm-overlay',
    onclick: (e) => { if (e.target === e.currentTarget) closeDialog(false); },
    onkeydown: (e) => { if (e.key === 'Escape') closeDialog(false); },
  },
    h('div', { class: 'qxm-dialog', role: 'alertdialog', 'aria-modal': 'true', tabindex: '-1' },
      h('div', { class: 'qxm-dialog-title' }, d.warn ? icon('alert') : icon('info'), d.title),
      d.warn
        ? h('div', { class: 'qxm-warn' }, icon('alert'), h('div', null, d.lines.map((l) => h('div', null, l))))
        : h('div', { class: 'qxm-panel-desc' }, d.lines.map((l) => h('div', null, l))),
      d.fields ? h('dl', { class: 'qxm-dialog-grid' }, d.fields.flatMap(([k, v]) => [h('dt', null, k), h('dd', { class: 'mono' }, v)])) : null,
      h('div', { class: 'qxm-dialog-actions' },
        d.cancelText ? h('button', { class: 'btn btn-ghost btn-sm', type: 'button', onclick: () => closeDialog(false) }, d.cancelText) : null,
        h('button', { class: (d.warn ? 'btn btn-danger' : 'btn btn-primary') + ' btn-sm', type: 'button', onclick: () => closeDialog(true) }, d.okText))));
}

/* ---------- 启动 ---------- */
bridge.initBridge().then(() => {
  state.bridgeStub = bridge.isStub();
  bridge.setTitle('插件市场').catch(() => {});
  bridge.onTheme(() => { /* 主题 class 由 bridge 内部切换，本应用样式全走令牌变量，无需重绘 */ }).catch(() => {});
  render();
});
loadCatalog();
loadInstalled();
render();
